# Never Gonna Give You Up

![Rickrolled](https://www.youtube.com/watch?v=FU2cyLDnMlo?autoplay=1)

## Lyrics
We're no strangers to love
我们都是老情圣了
You know the rules and so do I
你懂嘞个道理撒，我也晓得
A full commitment is what I'm thinking of
我在想一个冒日的承诺
You wouldn't get this from any other guy
在其他男娃儿那里你怕是找不到哦

I just wanna tell you how I'm feeling
我斗是告诉你我啷个想的
Gotta make you understand
求求你搞懂嘛


Never gonna give you up
绝对不得不要你老
Never gonna let you down
绝对不得让你失望
Never gonna run around and desert you
绝对不得到处灯儿晃把你撂了
Never gonna make you cry
绝对不得把你整哭
Never gonna say goodbye
绝对不得拜拜
Never gonna tell a lie and hurt you
绝对不得扯谎豁你


We've known each other for so long
我们都耍老嫩个久朋友老
Your heart has been aching, but you're too shy to say it
你心头青痛，斗是不好意思说个嘛
Inside, we both know what's been going on
掏心窝窝想一哈嘛，我们都晓得啷个回事
We know the game, and we're gonna play it
都懂啷个耍嘞个游戏，那斗开整

And if you ask me how I'm feeling
你要是问一哈我啷个想的
Don't tell me you're too blind to see
莫跟我说你晓求不得哈


Never gonna give you up
绝对不得不要你老
Never gonna let you down
绝对不得让你失望
Never gonna run around and desert you
绝对不得到处灯儿晃把你撂了
Never gonna make you cry
绝对不得把你整哭
Never gonna say goodbye
绝对不得拜拜
Never gonna tell a lie and hurt you
绝对不得扯谎豁你


Ooh (Give you up)
哦哦——（不要你老——）
Ooh-ooh (Give you up)
哦哦———（不要你老——）
Ooh-ooh
哦哦——
Never gonna give, never gonna give (Give you up)
绝对不得，绝对不得（不要你格老——）
Ooh-ooh
哦哦———
Never gonna give, never gonna give (Give you up)
绝对不得，绝对不得（不要你格老——）


We've known each other for so long
我们都认识嫩个久了
Your heart has been aching, but you're too shy to say it
你心头青痛，斗是不好意思说个嘛
Inside, we both know what's been going on
掏心窝窝想一哈嘛，我们都晓得啷个回事
We know the game, and we're gonna play it
都懂啷个耍嘞个游戏，那斗开整


Never gonna give you up
绝对不得不要你老
Never gonna let you down
绝对不得让你失望
Never gonna run around and desert you
绝对不得到处灯儿晃把你撂了
Never gonna make you cry
绝对不得把你整哭
Never gonna say goodbye
绝对不得拜拜
Never gonna tell a lie and hurt you
绝对不得扯谎豁你

Never gonna give you up
绝对不得不要你老
Never gonna let you down
绝对不得让你失望
Never gonna run around and desert you
绝对不得到处灯儿晃把你撂了
Never gonna make you cry
绝对不得把你整哭
Never gonna say goodbye
绝对不得拜拜
Never gonna tell a lie and hurt you
绝对不得扯谎豁你
