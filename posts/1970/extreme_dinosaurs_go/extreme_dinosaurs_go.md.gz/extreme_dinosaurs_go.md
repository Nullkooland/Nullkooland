# Extreme Dinosaurs, Go!

**God I love the 90s' cartoons!**

## The theme song

Something is really rocking, on planet No.3
第三号行星（地球）上，动静可不小

Human has got prehistoric companies
人类有了史前的伙伴

A clossal fossil feud, unlike anything before
前所未有的化石级争斗

Between the reckless raptors
在莽撞的迅猛龙

And the Extreme Dinosaurs!
与终极恐龙间展开！

EXTREME,
EXTREME,
EXTREME DINOSAURS!!!
终极，
终极，
终极恐龙！！！

Tails snap like thunderclap!
尾似惊雷劈除邪恶

Talking, stalking raptor trap!
行如闪电疾追敌人

EXTREME,
EXTREME,
EXTREME DINOSAURS!!!
终极，
终极，
终极恐龙！！！

The crash and smash Jurassic four:
不可阻挡的侏罗纪四龙组

Extreme Dinosaurs!
他们就是终极恐龙！

"Saurian stomp!"
“泰山脚！”

"Let's fossilize them!"
“把他们变成化石！”

EXTREME,
EXTREME,
EXTREME DINOSAURS!!!
终极，
终极，
终极恐龙！！！

Veloci(raptors)-tossing to the max!
把迅猛龙们打得满地找牙

They'll fossilize them in their tracks!
把他们就地变成化石！

EXTREME,
EXTREME,
EXTREME DINOSAURS!!!
终极，
终极，
终极恐龙！！！

The crash and smash Jurassic four:
不可阻挡的侏罗纪四龙组

EXTREME DINOSAURS——! 
终极恐龙——！！！

## The protagonists

T-Bone: a yellow Tyrannosaurus, as the leader. Always calm and composed. With the highest moral standard.

Spike: a sky blue Triceratops, as the fighter and cook. Impetuous and always eager to smash anything standing in his way.

Stegz: a light green Stegosaurus, as the tech guy. But unlike other nerdy cartoon characters, he could be quiet destructive since he can turn himself into a circular saw.

Bullzeye: a crimson Pteranodon, as the wise-cracking dude (I mean, literally, his ultrasound shriek can crack almost anything in this cartoon!) Prone to impulse buying (T-Bone: You don't need a high style hair salon if you don't have hair!!)

Hardrock: A tan Ankylosaurus, as... whatever. (Nah, I don't like this new guy anyway. You heard the theme song goes "The crash and smash Jurassic 4", which means no Ankylosaurus included!)

## The villains

Bad Rap: a yellow Velociraptor, as the leader of the bad team. He has a bad rap (terrible pun LOL) for his persistent obsession to cause global warming and make the world a raptor-ooland. (Man, how many cringe puns you've got!)

Spittor: a magenta Velociraptor, as the tech guy of the bad team (Stegz's villain counterpart). Who always love to spit various chemicals. (He is too kind to spit any lethal, erosive chemicals to the good dinosaurs!)

Haxx: a dark brown Velociraptor (Of course, all three villains are raptors, you are stating the obvious three times!), as the dump kid every other dinosaur (including his teammates) laugh at. Poor Haxx, there there, of course we still love you!
